############################################
# File for checking magisk version
############################################

MAGISK_VER="Alpha_31.0"
MAGISK_VER_CODE=23001
